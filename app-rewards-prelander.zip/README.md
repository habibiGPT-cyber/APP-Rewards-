# App Rewards Prelander

A clean, mobile-first prelander for MyLead Mobile CPI Smartlinks.  
Includes MyLead verification token and support for URL-based Smartlink injection.

## Features
- MyLead verification token in meta and page body.
- Mobile-friendly responsive layout.
- Button click or auto-redirect on mobile.
- Supports passing tracking subparams.

## Usage
Deploy to any static host (Vercel recommended).

### Passing your Smartlink
Append your MyLead Smartlink as a URL param:
```
https://<your-vercel-app>.vercel.app/?s=<URL-ENCODED_SMARTLINK>&sub=traffic1
```
- `s` → The full Smartlink (URL-encoded)
- `sub` (optional) → Passed to Smartlink as `ml_sub1`

## Deploy to Vercel
1. Create a new GitHub repo and push this folder.
2. Go to [Vercel](https://vercel.com) → **Add New Project** → Import your repo.
3. Framework: **Other**
4. Build Command: *(leave empty)*
5. Output Directory: `/`
6. Deploy and start sending traffic!
